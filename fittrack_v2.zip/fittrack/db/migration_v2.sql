-- FitTrack v2 migration (run once on an existing gym_system database)
USE gym_system;
ALTER TABLE tbl_members ADD COLUMN emergency_contact_name VARCHAR(100) NOT NULL DEFAULT '' AFTER phone, ADD COLUMN archived_at DATETIME NULL;
ALTER TABLE tbl_users ADD COLUMN archived_at DATETIME NULL;
UPDATE tbl_members SET emergency_contact_name=ELT(member_id,'Rosa Dela Cruz','Pedro Santos','Elena Reyes','Luis Garcia','Carmen Lopez','Ramon Ramos','Teresa Mendoza','Jose Navarro') WHERE member_id BETWEEN 1 AND 8 AND emergency_contact_name='';
UPDATE tbl_members SET address=CONCAT('Brgy. Uno, ',address) WHERE address NOT LIKE '%,%,%';
INSERT INTO tbl_members (first_name,last_name,email,phone,emergency_contact,emergency_contact_name,date_of_birth,address,registration_date,status)
SELECT 'Paolo','Villar','paolo.villar@email.com','09271234567','09281234567','Nena Villar','2000-06-15','Macabling, Santa Rosa, Laguna',DATE_SUB(CURDATE(),INTERVAL 27 DAY),'Active' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM tbl_members WHERE email='paolo.villar@email.com');
INSERT INTO tbl_memberships (member_id,plan_id,start_date,end_date,status)
SELECT member_id,1,DATE_SUB(CURDATE(),INTERVAL 27 DAY),DATE_ADD(CURDATE(),INTERVAL 3 DAY),'Active' FROM tbl_members m
WHERE email='paolo.villar@email.com' AND NOT EXISTS (SELECT 1 FROM tbl_memberships WHERE member_id=m.member_id);
INSERT INTO tbl_payments (membership_id,amount,payment_method)
SELECT ms.membership_id,800.00,'Cash' FROM tbl_memberships ms JOIN tbl_members m ON m.member_id=ms.member_id
WHERE m.email='paolo.villar@email.com' AND NOT EXISTS (SELECT 1 FROM tbl_payments WHERE membership_id=ms.membership_id);
