require('dotenv').config();
const express=require('express'),mysql=require('mysql2/promise'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),path=require('path');
const app=express();app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
app.get('/',(q,s)=>s.redirect('/login.html'));
const db=mysql.createPool({host:process.env.DB_HOST||'localhost',user:process.env.DB_USER||'root',password:process.env.DB_PASS||'',database:'gym_system',dateStrings:true});
const SECRET=process.env.JWT_SECRET||'change-me',PER=10;
const h=f=>(q,s,n)=>f(q,s,n).catch(e=>{console.error(e);const d=e.code==='ER_DUP_ENTRY';s.status(e.status||(d?409:500)).json({error:e.status?e.message:d?'Email already exists':(e.sqlMessage||e.message)})});
const bad=m=>{const e=new Error(m);e.status=400;throw e};
// auth re-checks the DB so deactivating/archiving a user ends their session immediately
const auth=async(q,s,n)=>{try{const u=jwt.verify((q.headers.authorization||'').slice(7),SECRET);
  const[[r]]=await db.query('SELECT role,status,archived_at FROM tbl_users WHERE user_id=?',[u.id]);
  if(!r||r.status!=='Active'||r.archived_at)return s.status(401).json({error:'Session ended'});q.user={...u,role:r.role};}catch{return s.status(401).json({error:'Unauthorized'})}n()};
const admin=(q,s,n)=>q.user.role==='admin'?n():s.status(403).json({error:'Admin only'});
const MEM=`SELECT m.member_id,m.first_name,m.last_name,m.email,m.phone,m.emergency_contact,m.emergency_contact_name,m.date_of_birth,m.address,m.archived_at,ms.membership_id,p.plan_name,ms.start_date,ms.end_date,DATEDIFF(ms.end_date,CURDATE()) AS days_left,EXISTS(SELECT 1 FROM tbl_attendance WHERE member_id=m.member_id AND check_out IS NULL) AS is_checked_in,IF(ms.status='Active' AND ms.end_date>=CURDATE(),'Active','Inactive') AS status FROM tbl_members m LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=m.member_id) LEFT JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id`;
const page=async(s,q,cnt,sql,a=[],extra={})=>{const pg=Math.max(1,+q.query.page||1);const[[{n}]]=await db.query(cnt,a);const[rows]=await db.query(sql+' LIMIT ? OFFSET ?',[...a,PER,(pg-1)*PER]);s.json({rows,total:n,pages:Math.ceil(n/PER)||1,...extra})};
const num=v=>String(v||'').replace(/\D/g,'');
// sort keys are whitelisted; first key is the default; id tiebreaker always appended
const ord=(map,k,idc)=>' ORDER BY '+(Object.prototype.hasOwnProperty.call(map,k)?map[k]:Object.values(map)[0])+','+idc;
const SM={id_asc:'m.member_id',id_desc:'m.member_id DESC',name_asc:'m.last_name,m.first_name',name_desc:'m.last_name DESC,m.first_name DESC',plan:'p.plan_name IS NULL,p.plan_name',end_asc:'ms.end_date IS NULL,ms.end_date',end_desc:'ms.end_date IS NULL,ms.end_date DESC',status:"(ms.status='Active' AND ms.end_date>=CURDATE()) DESC"};
const SA={newest:'a.check_in DESC',oldest:'a.check_in',name_asc:'m.last_name,m.first_name',name_desc:'m.last_name DESC,m.first_name DESC',inside:'(a.check_out IS NULL) DESC,a.check_in DESC'};
const SP={newest:'pay.payment_date DESC',oldest:'pay.payment_date',amount_desc:'pay.amount DESC',amount_asc:'pay.amount',name_asc:'m.last_name,m.first_name',method:'pay.payment_method'};
const SU={name_asc:'first_name,last_name',name_desc:'first_name DESC,last_name DESC',status:'status',newest:'user_id DESC',oldest:'user_id'};
const normPhone=v=>{const c=String(v||'').replace(/[\s\-()]/g,'');return/^(?:\+?63|0)9\d{9}$/.test(c)?'0'+c.slice(-10):null};
const addrOk=a=>{const p=String(a||'').split(',').map(x=>x.trim());return p.length>=3&&p.every(Boolean)};
function vm(b){for(const k of['first_name','last_name','email','emergency_contact_name','address'])b[k]=String(b[k]||'').trim();
  if(!b.first_name||!b.last_name||!b.email||!b.emergency_contact_name||!b.date_of_birth)bad('Please fill in all required fields');
  const p=normPhone(b.phone),e=normPhone(b.emergency_contact);
  if(!p)bad('Enter a valid Philippine mobile number for Phone Number');
  if(!e)bad('Enter a valid Philippine mobile number for Emergency Contact Number');
  if(!addrOk(b.address))bad('Please include barangay, city/municipality, and province, separated by commas.');
  b.phone=p;b.emergency_contact=e}

app.post('/api/auth/login',h(async(q,s)=>{
  const[[u]]=await db.query('SELECT * FROM tbl_users WHERE email=? AND status="Active" AND archived_at IS NULL',[q.body.email||'']);
  if(!u||!await bcrypt.compare(q.body.password||'',u.password_hash))return s.status(401).json({error:'Invalid email or password'});
  const user={id:u.user_id,name:u.first_name+' '+u.last_name,email:u.email,role:u.role};
  s.json({token:jwt.sign(user,SECRET,{expiresIn:'8h'}),user});
}));
app.use('/api',auth);

app.get('/api/dashboard',h(async(q,s)=>{
  const[[{total}]]=await db.query('SELECT COUNT(*) total FROM tbl_members WHERE archived_at IS NULL');
  const[[{today}]]=await db.query('SELECT COUNT(DISTINCT a.member_id) today FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id WHERE DATE(a.check_in)=CURDATE() AND m.archived_at IS NULL');
  const[expiring]=await db.query(`SELECT m.member_id,m.first_name,m.last_name,DATEDIFF(ms.end_date,CURDATE()) days_left FROM tbl_memberships ms JOIN tbl_members m ON m.member_id=ms.member_id WHERE m.archived_at IS NULL AND ms.status='Active' AND ms.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) ORDER BY ms.end_date,m.member_id`);
  const[recent]=await db.query('SELECT a.member_id,m.first_name,m.last_name,a.check_in,a.check_out FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id ORDER BY a.check_in DESC,a.attendance_id DESC LIMIT 5');
  s.json({total,today,expiring,recent});
}));

app.get('/api/plans',h(async(q,s)=>{
  const[plans]=await db.query('SELECT * FROM tbl_membership_plans ORDER BY plan_id');
  const[ps]=await db.query('SELECT plan_id,service_id FROM tbl_plan_services');
  const[services]=await db.query('SELECT * FROM tbl_services ORDER BY service_id');
  plans.forEach(p=>p.included=ps.filter(x=>x.plan_id===p.plan_id).map(x=>x.service_id));
  s.json({plans,services});
}));

app.get('/api/members',h(async(q,s)=>{
  const t=`%${q.query.search||''}%`,a=[t,t,t,t,+q.query.search||0];
  const w=` WHERE m.archived_at IS ${q.query.archived==='1'?'NOT NULL':'NULL'} AND (CONCAT(m.first_name," ",m.last_name) LIKE ? OR m.email LIKE ? OR m.phone LIKE ? OR CONCAT("FT",LPAD(m.member_id,3,"0")) LIKE ? OR m.member_id=?)`;
  await page(s,q,'SELECT COUNT(*) n FROM tbl_members m'+w,MEM+w+ord(SM,q.query.sort,'m.member_id'),a);
}));
app.get('/api/members/:id',h(async(q,s)=>{
  const id=num(q.params.id);const[[m]]=await db.query(MEM+' WHERE m.member_id=?',[id]);
  if(!m)return s.status(404).json({error:'Member not found'});
  const[[a]]=await db.query('SELECT MAX(check_in) last_check_in FROM tbl_attendance WHERE member_id=?',[id]);
  s.json({...m,...a,is_checked_in:!!m.is_checked_in});
}));
app.post('/api/members',h(async(q,s)=>{
  const b=q.body;vm(b);const c=await db.getConnection();
  try{await c.beginTransaction();
    const[[p]]=await c.query('SELECT * FROM tbl_membership_plans WHERE plan_id=?',[b.plan_id]);if(!p)bad('Select a membership plan');
    if(!['Cash','GCash','Bank Transfer','Card'].includes(b.payment_method))bad('Select a payment method');
    const[inc]=await c.query('SELECT service_id FROM tbl_plan_services WHERE plan_id=?',[p.plan_id]);const incl=inc.map(x=>x.service_id);
    let total=+p.price;
    for(const sid of b.addons||[]){if(incl.includes(+sid))continue;const[[sv]]=await c.query('SELECT price FROM tbl_services WHERE service_id=?',[sid]);if(sv)total+=+sv.price}
    const[r]=await c.query('INSERT INTO tbl_members(first_name,last_name,email,phone,emergency_contact_name,emergency_contact,date_of_birth,address,registration_date) VALUES(?,?,?,?,?,?,?,?,CURDATE())',[b.first_name,b.last_name,b.email,b.phone,b.emergency_contact_name,b.emergency_contact,b.date_of_birth,b.address]);
    const[ms]=await c.query('INSERT INTO tbl_memberships(member_id,plan_id,start_date,end_date,status) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL ? MONTH),"Active")',[r.insertId,p.plan_id,p.duration_months]);
    await c.query('INSERT INTO tbl_payments(membership_id,amount,payment_method) VALUES(?,?,?)',[ms.insertId,total,b.payment_method]);
    await c.commit();s.json({member_id:r.insertId,total});
  }catch(e){await c.rollback();throw e}finally{c.release()}
}));
app.put('/api/members/:id',h(async(q,s)=>{
  const b=q.body;vm(b);
  await db.query('UPDATE tbl_members SET first_name=?,last_name=?,email=?,phone=?,emergency_contact_name=?,emergency_contact=?,date_of_birth=?,address=? WHERE member_id=?',[b.first_name,b.last_name,b.email,b.phone,b.emergency_contact_name,b.emergency_contact,b.date_of_birth,b.address,num(q.params.id)]);s.json({ok:true});
}));
// no hard delete: members are archived; payments and attendance are never removed
app.post('/api/members/:id/archive',h(async(q,s)=>{
  const id=num(q.params.id);await db.query('UPDATE tbl_attendance SET check_out=NOW() WHERE member_id=? AND check_out IS NULL',[id]);
  await db.query('UPDATE tbl_members SET archived_at=NOW() WHERE member_id=?',[id]);s.json({ok:true});
}));
app.post('/api/members/:id/restore',h(async(q,s)=>{await db.query('UPDATE tbl_members SET archived_at=NULL WHERE member_id=?',[num(q.params.id)]);s.json({ok:true})}));
app.post('/api/members/:id/cancel',h(async(q,s)=>{
  const id=num(q.params.id);
  await db.query("UPDATE tbl_memberships SET status='Inactive' WHERE membership_id=(SELECT x.mid FROM (SELECT MAX(membership_id) mid FROM tbl_memberships WHERE member_id=?) x)",[id]);
  await db.query("UPDATE tbl_members SET status='Inactive' WHERE member_id=?",[id]);s.json({ok:true});
}));

app.post('/api/attendance',h(async(q,s)=>{
  const id=num(q.body.member_id);const[[m]]=await db.query(MEM+' WHERE m.member_id=?',[id]);
  if(!m)return s.status(404).json({error:'Member not found'});
  const[[open]]=await db.query('SELECT attendance_id FROM tbl_attendance WHERE member_id=? AND check_out IS NULL ORDER BY check_in DESC LIMIT 1',[id]);
  if(open){await db.query('UPDATE tbl_attendance SET check_out=NOW() WHERE attendance_id=?',[open.attendance_id]);return s.json({action:'out',message:m.first_name+' checked out'})}
  if(m.archived_at)return s.status(400).json({error:'Archived members cannot check in'});
  if(m.status!=='Active')return s.status(400).json({error:'Membership is not active'});
  await db.query('INSERT INTO tbl_attendance(member_id) VALUES(?)',[id]);s.json({action:'in',message:m.first_name+' checked in'});
}));
app.get('/api/attendance',h(async(q,s)=>{
  const t=`%${q.query.search||''}%`,w=' WHERE CONCAT(m.first_name," ",m.last_name) LIKE ? OR CONCAT("FT",LPAD(m.member_id,3,"0")) LIKE ?';
  const j=' FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=m.member_id) LEFT JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id'+w;
  await page(s,q,'SELECT COUNT(*) n'+j,'SELECT a.attendance_id,m.member_id,m.first_name,m.last_name,p.plan_name,a.check_in,a.check_out'+j+ord(SA,q.query.sort,'a.attendance_id'),[t,t]);
}));
app.get('/api/payments',h(async(q,s)=>{
  const[[{total}]]=await db.query('SELECT COALESCE(SUM(amount),0) total FROM tbl_payments');
  const j=' FROM tbl_payments pay JOIN tbl_memberships ms ON ms.membership_id=pay.membership_id JOIN tbl_members m ON m.member_id=ms.member_id JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id';
  await page(s,q,'SELECT COUNT(*) n'+j,'SELECT pay.payment_id,pay.amount,pay.payment_date,pay.payment_method,m.member_id,m.first_name,m.last_name,p.plan_name'+j+ord(SP,q.query.sort,'pay.payment_id'),[],{revenue:total});
}));

app.get('/api/accounts',admin,h(async(q,s)=>{
  const[rows]=await db.query(`SELECT user_id,first_name,last_name,email,phone,status,archived_at FROM tbl_users WHERE role='staff' AND archived_at IS ${q.query.archived==='1'?'NOT NULL':'NULL'}`+ord(SU,q.query.sort,'user_id'));s.json(rows);
}));
app.post('/api/accounts',admin,h(async(q,s)=>{
  const b=q.body;if(!b.first_name||!b.last_name||!b.email||!b.phone||!b.password||b.password.length<6)bad('All fields required (password min 6 chars)');
  if(b.password!==b.confirm_password)bad('Passwords do not match');
  await db.query("INSERT INTO tbl_users(first_name,last_name,email,phone,password_hash,role) VALUES(?,?,?,?,?,'staff')",[b.first_name,b.last_name,b.email,b.phone,await bcrypt.hash(b.password,10)]);s.json({ok:true});
}));
app.patch('/api/accounts/:id/status',admin,h(async(q,s)=>{
  if(!['Active','Inactive'].includes(q.body.status))bad('Invalid status');
  await db.query("UPDATE tbl_users SET status=? WHERE user_id=? AND role='staff'",[q.body.status,q.params.id]);s.json({ok:true});
}));
app.post('/api/accounts/:id/archive',admin,h(async(q,s)=>{await db.query("UPDATE tbl_users SET archived_at=NOW() WHERE user_id=? AND role='staff'",[q.params.id]);s.json({ok:true})}));
app.post('/api/accounts/:id/restore',admin,h(async(q,s)=>{await db.query("UPDATE tbl_users SET archived_at=NULL,status='Inactive' WHERE user_id=? AND role='staff'",[q.params.id]);s.json({ok:true})}));

app.listen(process.env.PORT||3000,()=>console.log('FitTrack running on http://localhost:'+(process.env.PORT||3000)));
