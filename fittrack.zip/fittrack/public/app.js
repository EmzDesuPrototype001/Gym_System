const T=localStorage.getItem('ft_token'),U=JSON.parse(localStorage.getItem('ft_user')||'null');
const $=(s,r=document)=>r.querySelector(s);
function logout(){localStorage.clear();location.href='login.html'}
async function api(u,o={}){const r=await fetch('/api'+u,{method:o.method||'GET',headers:{'Content-Type':'application/json',Authorization:'Bearer '+T},body:o.body?JSON.stringify(o.body):undefined});
  const d=await r.json().catch(()=>({}));if(r.status===401&&!u.startsWith('/auth'))logout();if(!r.ok)throw new Error(d.error||'Request failed');return d}
const fid=id=>'FT'+String(id).padStart(3,'0');
const av=(f,l)=>`<span class="av">${((f||'?')[0]+((l||'')[0]||'')).toUpperCase()}</span>`;
const fd=d=>d?new Date(d.slice(0,10)+'T00:00').toLocaleDateString('en-PH',{day:'2-digit',month:'short',year:'numeric'}):'—';
const fdt=d=>d?new Date(d.replace(' ','T')).toLocaleString('en-PH',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—';
const peso=n=>'₱'+Number(n).toLocaleString('en-PH',{minimumFractionDigits:2});
const planCls={Basic:'b-blue',Standard:'b-red',Premium:'b-amber',Annual:'b-green'};
const badge=(t,c)=>`<span class="pill ${c}">${t}</span>`;
const today=()=>new Date().toLocaleDateString('en-PH',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+' — Welcome back, '+(U?U.name.split(' ')[0]:'')+'!';
function toast(m,ok=true){const d=document.createElement('div');d.className='ft-toast '+(ok?'ok':'bad');d.textContent=m;document.body.appendChild(d);setTimeout(()=>d.remove(),3000)}
window.addEventListener('unhandledrejection',e=>toast(e.reason&&e.reason.message||'Error',false));
function modal(html,size=''){const e=document.createElement('div');e.className='modal fade';e.innerHTML=`<div class="modal-dialog modal-dialog-centered ${size}"><div class="modal-content">${html}</div></div>`;document.body.appendChild(e);const m=new bootstrap.Modal(e);e.addEventListener('hidden.bs.modal',()=>e.remove());m.show();e.hide=()=>m.hide();return e}
function confirmBox({title,text,icon,onYes,logoutStyle}){
  const btns=logoutStyle?`<button class="btn btn-outline-light flex-fill" data-bs-dismiss="modal">Cancel</button><button class="btn btn-red flex-fill" id="y">Logout</button>`:`<button class="btn btn-outline-light flex-fill" id="y">Yes</button><button class="btn btn-red flex-fill" data-bs-dismiss="modal">Cancel</button>`;
  const e=modal(`<div class="p-4 text-center"><h5>${title}</h5><i class="bi ${icon} big"></i><p class="mt-3 mb-4">${text}</p><div class="d-flex gap-2">${btns}</div></div>`);
  $('#y',e).onclick=async()=>{e.hide();try{await onYes()}catch(x){toast(x.message,false)}}}
const delBox=(what,onYes)=>confirmBox({title:'Delete confirmation',text:`Are you sure you want to delete this ${what}?`,icon:'bi-exclamation-triangle',onYes});
function pager(el,page,pages,go){
  let h=`<li class="page-item ${page==1?'disabled':''}"><a class="page-link" data-p="1">First</a></li>`;
  for(let i=Math.max(1,page-1);i<=Math.min(pages,page+2);i++)h+=`<li class="page-item ${i==page?'active':''}"><a class="page-link" data-p="${i}">${i}</a></li>`;
  if(page+2<pages)h+='<li class="page-item disabled"><a class="page-link">…</a></li>';
  h+=`<li class="page-item ${page==pages?'disabled':''}"><a class="page-link" data-p="${pages}">Last</a></li>`;
  el.innerHTML=h;el.onclick=e=>{const p=e.target.dataset.p;if(p)go(+p)}}
function shell(title,sub,active,right=''){
  if(!T||!U){location.href='login.html';return false}
  const nav=[['dashboard','Dashboard','bi-grid'],['members','Members','bi-people'],['attendance','Attendance','bi-calendar-check'],['payments','Payments','bi-currency-dollar']];
  const[fn,ln]=U.name.split(' ');
  $('#root').innerHTML=`<div class="layout"><aside class="sidebar"><div class="brand">FITTRACK<small>FITNESS CENTER</small></div>
  <div class="profile">${av(fn,ln)}<div><b>${U.name}</b><div class="role ${U.role}">${U.role==='admin'?'Admin':'Staff'}</div></div></div>
  <nav>${nav.map(n=>`<a href="${n[0]}.html" class="${active===n[0]?'active':''}"><i class="bi ${n[2]}"></i><span>${n[1]}</span></a>`).join('')}</nav>
  <div>${U.role==='admin'?`<a href="accounts.html" class="${active==='accounts'?'active':''}"><i class="bi bi-person-gear"></i><span>Accounts</span></a>`:''}<a href="#" class="text-red" id="lo"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a></div></aside>
  <div class="main"><header><div><h4>${title}</h4><small>${sub}</small></div><div>${right}</div></header><div class="content" id="app"></div></div></div>`;
  $('#lo').onclick=e=>{e.preventDefault();confirmBox({title:'Logout Confirmation',text:'Are you sure you want to Logout of the FITTRACK System?',icon:'bi-power',logoutStyle:true,onYes:logout})};
  return true}
async function profileModal(id,onChange,startEdit=false){
  let m=await api('/members/'+id),edit=startEdit;
  const e=modal('<div id="pf"></div>','modal-lg');
  const reload=async()=>{m=await api('/members/'+id);draw();onChange&&onChange()};
  function draw(){
    const days=m.end_date?Math.max(0,Math.ceil((new Date(m.end_date)-new Date())/864e5)):0;
    const tot=m.start_date?Math.max(1,(new Date(m.end_date)-new Date(m.start_date))/864e5):1;
    const pct=Math.min(100,Math.max(0,100-days/tot*100));
    const inp=(k,l,t='text')=>`<div class="col-6"><label>${l}</label><input class="form-control form-control-sm" id="f_${k}" type="${t}" value="${m[k]||''}"></div>`;
    $('#pf',e).innerHTML=`<div class="pf-head">${av(m.first_name,m.last_name)}<div class="flex-fill">${edit?`<div class="row g-1">${inp('first_name','First name')}${inp('last_name','Last name')}${inp('email','Email','email')}${inp('phone','Contact number')}${inp('emergency_contact','Emergency contact')}${inp('date_of_birth','Birthday','date')}</div><div class="mt-2"><button class="btn btn-sm btn-green" id="sv">Save</button> <button class="btn btn-sm btn-outline-light" id="cn">Cancel</button></div>`:
    `<h4 class="mb-1">${m.first_name} ${m.last_name}</h4><div>${m.email}</div><div>${m.phone}</div><div>Emergency contact: ${m.emergency_contact}</div><div>Birthday: ${fd(m.date_of_birth)}</div><b>ID: ${fid(m.member_id)}</b>`}</div>${edit?'':'<button class="btn text-white fs-5" id="ed"><i class="bi bi-pencil-square"></i></button>'}</div>
    <div class="pf-box"><div class="d-flex justify-content-between align-items-start"><div><small>Membership Plan</small><h3 class="fw-bold fst-italic text-danger">${m.plan_name||'No plan'}</h3></div>${badge(m.status,m.status==='Active'?'b-green':'b-red')}</div>
    <div class="d-flex justify-content-between"><div><small>Join Date</small><div class="fw-bold">${fd(m.start_date)}</div></div><div class="text-end"><small>End Date</small><div class="fw-bold">${fd(m.end_date)}</div></div></div>
    <div class="progress my-2"><div class="progress-bar" style="width:${pct}%"></div></div><div class="fw-bold">${days} days left in your plan</div><hr><small>Membership ID</small><div class="fw-bold">${fid(m.member_id)}</div>
    <div class="mt-3 p-2 rounded d-inline-block" style="background:#475a77"><small class="text-white">Latest check-in</small><div class="fw-bold">${fdt(m.last_check_in)}</div></div>
    <div class="d-flex gap-3 mt-3"><button class="btn btn-red flex-fill" id="cm">Cancel Membership</button><button class="btn btn-green flex-fill" id="ci">Check-In</button></div></div>`;
    if(edit){$('#cn',e).onclick=()=>{edit=false;draw()};$('#sv',e).onclick=async()=>{const b={};['first_name','last_name','email','phone','emergency_contact','date_of_birth'].forEach(k=>b[k]=$('#f_'+k,e).value);
      try{await api('/members/'+id,{method:'PUT',body:b});toast('Profile updated');edit=false;reload()}catch(x){toast(x.message,false)}}}
    else $('#ed',e).onclick=()=>{edit=true;draw()};
    $('#ci',e).onclick=async()=>{try{const r=await api('/attendance',{method:'POST',body:{member_id:id}});toast(r.message);reload()}catch(x){toast(x.message,false)}};
    $('#cm',e).onclick=()=>confirmBox({title:'Cancellation confirmation',text:'Are you sure you want to cancel this membership?',icon:'bi-exclamation-triangle',onYes:async()=>{await api(`/members/${id}/cancel`,{method:'POST'});toast('Membership cancelled');reload()}});
  }
  draw()}
