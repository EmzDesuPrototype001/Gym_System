require('dotenv').config();
const express=require('express'),mysql=require('mysql2/promise'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),path=require('path');
const app=express();app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
const db=mysql.createPool({host:process.env.DB_HOST||'localhost',user:process.env.DB_USER||'root',password:process.env.DB_PASS||'',database:'gym_system',dateStrings:true});
const SECRET=process.env.JWT_SECRET||'change-me',PER=10;
const h=f=>(q,s,n)=>f(q,s,n).catch(e=>{console.error(e);s.status(e.code==='ER_DUP_ENTRY'?409:500).json({error:e.code==='ER_DUP_ENTRY'?'Email already exists':(e.sqlMessage||e.message)})});
const auth=(q,s,n)=>{try{q.user=jwt.verify((q.headers.authorization||'').slice(7),SECRET);n()}catch{s.status(401).json({error:'Unauthorized'})}};
const admin=(q,s,n)=>q.user.role==='admin'?n():s.status(403).json({error:'Admin only'});
// latest membership per member; status = Active only if not expired (no "Pending" state)
const MEM=`SELECT m.member_id,m.first_name,m.last_name,m.email,m.phone,m.emergency_contact,m.date_of_birth,m.address,ms.membership_id,p.plan_name,ms.start_date,ms.end_date,IF(ms.status='Active' AND ms.end_date>=CURDATE(),'Active','Inactive') AS status FROM tbl_members m LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=m.member_id) LEFT JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id`;
const page=async(s,q,cnt,sql,a=[],extra={})=>{const pg=Math.max(1,+q.query.page||1);const[[{n}]]=await db.query(cnt,a);const[rows]=await db.query(sql+' LIMIT ? OFFSET ?',[...a,PER,(pg-1)*PER]);s.json({rows,total:n,pages:Math.ceil(n/PER)||1,...extra})};
const num=v=>String(v||'').replace(/\D/g,'');

app.post('/api/auth/login',h(async(q,s)=>{
  const[[u]]=await db.query('SELECT * FROM tbl_users WHERE email=? AND status="Active"',[q.body.email||'']);
  if(!u||!await bcrypt.compare(q.body.password||'',u.password_hash))return s.status(401).json({error:'Invalid email or password'});
  const user={id:u.user_id,name:u.first_name+' '+u.last_name,email:u.email,role:u.role};
  s.json({token:jwt.sign(user,SECRET,{expiresIn:'8h'}),user});
}));
app.use('/api',auth);

app.get('/api/dashboard',h(async(q,s)=>{
  const[[{total}]]=await db.query('SELECT COUNT(*) total FROM tbl_members');
  const[[{today}]]=await db.query('SELECT COUNT(DISTINCT member_id) today FROM tbl_attendance WHERE DATE(check_in)=CURDATE()');
  const[expiring]=await db.query(`SELECT m.member_id,m.first_name,m.last_name,DATEDIFF(ms.end_date,CURDATE()) days_left FROM tbl_memberships ms JOIN tbl_members m ON m.member_id=ms.member_id WHERE ms.status='Active' AND ms.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) ORDER BY ms.end_date`);
  const[recent]=await db.query('SELECT a.member_id,m.first_name,m.last_name,a.check_in,a.check_out FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id ORDER BY a.check_in DESC LIMIT 5');
  s.json({total,today,expiring,recent});
}));

app.get('/api/plans',h(async(q,s)=>{
  const[plans]=await db.query('SELECT * FROM tbl_membership_plans ORDER BY plan_id');
  const[ps]=await db.query('SELECT plan_id,service_id FROM tbl_plan_services');
  const[services]=await db.query('SELECT * FROM tbl_services ORDER BY service_id');
  plans.forEach(p=>p.included=ps.filter(x=>x.plan_id===p.plan_id).map(x=>x.service_id));
  s.json({plans,services});
}));

app.get('/api/members',h(async(q,s)=>{
  const t=`%${q.query.search||''}%`,a=[t,t,t,t,+q.query.search||0];
  const w=' WHERE CONCAT(m.first_name," ",m.last_name) LIKE ? OR m.email LIKE ? OR m.phone LIKE ? OR CONCAT("FT",LPAD(m.member_id,3,"0")) LIKE ? OR m.member_id=?';
  await page(s,q,'SELECT COUNT(*) n FROM tbl_members m'+w,MEM+w+' ORDER BY m.member_id',a);
}));
app.get('/api/members/:id',h(async(q,s)=>{
  const id=num(q.params.id);const[[m]]=await db.query(MEM+' WHERE m.member_id=?',[id]);
  if(!m)return s.status(404).json({error:'Member not found'});
  const[[a]]=await db.query('SELECT MAX(check_in) last_check_in FROM tbl_attendance WHERE member_id=?',[id]);
  s.json({...m,...a});
}));
app.post('/api/members',h(async(q,s)=>{
  const b=q.body,c=await db.getConnection();
  try{await c.beginTransaction();
    const[[p]]=await c.query('SELECT * FROM tbl_membership_plans WHERE plan_id=?',[b.plan_id]);if(!p)throw new Error('Select a membership plan');
    const[inc]=await c.query('SELECT service_id FROM tbl_plan_services WHERE plan_id=?',[p.plan_id]);const incl=inc.map(x=>x.service_id);
    let total=+p.price;
    for(const sid of b.addons||[]){if(incl.includes(+sid))continue;const[[sv]]=await c.query('SELECT price FROM tbl_services WHERE service_id=?',[sid]);if(sv)total+=+sv.price}
    const[r]=await c.query('INSERT INTO tbl_members(first_name,last_name,email,phone,emergency_contact,date_of_birth,address,registration_date) VALUES(?,?,?,?,?,?,?,CURDATE())',[b.first_name,b.last_name,b.email,b.phone,b.emergency_contact,b.date_of_birth,b.address]);
    const[ms]=await c.query('INSERT INTO tbl_memberships(member_id,plan_id,start_date,end_date,status) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL ? MONTH),"Active")',[r.insertId,p.plan_id,p.duration_months]);
    await c.query('INSERT INTO tbl_payments(membership_id,amount,payment_method) VALUES(?,?,?)',[ms.insertId,total,b.payment_method]);
    await c.commit();s.json({member_id:r.insertId,total});
  }catch(e){await c.rollback();throw e}finally{c.release()}
}));
app.put('/api/members/:id',h(async(q,s)=>{
  const b=q.body;await db.query('UPDATE tbl_members SET first_name=?,last_name=?,email=?,phone=?,emergency_contact=?,date_of_birth=? WHERE member_id=?',[b.first_name,b.last_name,b.email,b.phone,b.emergency_contact,b.date_of_birth,num(q.params.id)]);s.json({ok:true});
}));
app.delete('/api/members/:id',h(async(q,s)=>{
  const id=num(q.params.id),c=await db.getConnection();
  try{await c.beginTransaction();
    await c.query('DELETE FROM tbl_payments WHERE membership_id IN (SELECT membership_id FROM tbl_memberships WHERE member_id=?)',[id]);
    await c.query('DELETE FROM tbl_attendance WHERE member_id=?',[id]);
    await c.query('DELETE FROM tbl_memberships WHERE member_id=?',[id]);
    await c.query('DELETE FROM tbl_members WHERE member_id=?',[id]);
    await c.commit();s.json({ok:true});
  }catch(e){await c.rollback();throw e}finally{c.release()}
}));
app.post('/api/members/:id/cancel',h(async(q,s)=>{
  const id=num(q.params.id);
  await db.query("UPDATE tbl_memberships SET status='Inactive' WHERE membership_id=(SELECT x.mid FROM (SELECT MAX(membership_id) mid FROM tbl_memberships WHERE member_id=?) x)",[id]);
  await db.query("UPDATE tbl_members SET status='Inactive' WHERE member_id=?",[id]);s.json({ok:true});
}));

// toggles: check-in if not inside, otherwise check-out
app.post('/api/attendance',h(async(q,s)=>{
  const id=num(q.body.member_id);const[[m]]=await db.query(MEM+' WHERE m.member_id=?',[id]);
  if(!m)return s.status(404).json({error:'Member not found'});
  const[[open]]=await db.query('SELECT attendance_id FROM tbl_attendance WHERE member_id=? AND check_out IS NULL ORDER BY check_in DESC LIMIT 1',[id]);
  if(open){await db.query('UPDATE tbl_attendance SET check_out=NOW() WHERE attendance_id=?',[open.attendance_id]);return s.json({action:'out',message:m.first_name+' checked out'})}
  if(m.status!=='Active')return s.status(400).json({error:'Membership is not active'});
  await db.query('INSERT INTO tbl_attendance(member_id) VALUES(?)',[id]);s.json({action:'in',message:m.first_name+' checked in'});
}));
app.get('/api/attendance',h(async(q,s)=>{
  const t=`%${q.query.search||''}%`,w=' WHERE CONCAT(m.first_name," ",m.last_name) LIKE ? OR CONCAT("FT",LPAD(m.member_id,3,"0")) LIKE ?';
  const j=' FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=m.member_id) LEFT JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id'+w;
  await page(s,q,'SELECT COUNT(*) n'+j,'SELECT a.attendance_id,m.member_id,m.first_name,m.last_name,p.plan_name,a.check_in,a.check_out'+j+' ORDER BY a.check_in DESC',[t,t]);
}));

app.get('/api/payments',h(async(q,s)=>{
  const[[{total}]]=await db.query('SELECT COALESCE(SUM(amount),0) total FROM tbl_payments');
  const j=' FROM tbl_payments pay JOIN tbl_memberships ms ON ms.membership_id=pay.membership_id JOIN tbl_members m ON m.member_id=ms.member_id JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id';
  await page(s,q,'SELECT COUNT(*) n'+j,'SELECT pay.payment_id,pay.amount,pay.payment_date,pay.payment_method,m.member_id,m.first_name,m.last_name,p.plan_name'+j+' ORDER BY pay.payment_date DESC',[],{revenue:total});
}));

app.get('/api/accounts',admin,h(async(q,s)=>{
  const[rows]=await db.query("SELECT user_id,first_name,last_name,email,phone,status FROM tbl_users WHERE role='staff' ORDER BY user_id");s.json(rows);
}));
app.post('/api/accounts',admin,h(async(q,s)=>{
  const b=q.body;if(!b.first_name||!b.last_name||!b.email||!b.phone||!b.password||b.password.length<6)return s.status(400).json({error:'All fields required (password min 6 chars)'});
  await db.query("INSERT INTO tbl_users(first_name,last_name,email,phone,password_hash,role) VALUES(?,?,?,?,?,'staff')",[b.first_name,b.last_name,b.email,b.phone,await bcrypt.hash(b.password,10)]);s.json({ok:true});
}));
app.delete('/api/accounts/:id',admin,h(async(q,s)=>{
  await db.query("DELETE FROM tbl_users WHERE user_id=? AND role='staff'",[q.params.id]);s.json({ok:true});
}));

app.listen(process.env.PORT||3000,()=>console.log('FitTrack running on http://localhost:'+(process.env.PORT||3000)));
