const T=localStorage.getItem('ft_token'),U=JSON.parse(localStorage.getItem('ft_user')||'null');
const $=(s,r=document)=>r.querySelector(s);
function logout(){localStorage.clear();location.href='login.html'}
async function api(u,o={}){const r=await fetch('/api'+u,{method:o.method||'GET',headers:{'Content-Type':'application/json',Authorization:'Bearer '+T},body:o.body?JSON.stringify(o.body):undefined});
  const d=await r.json().catch(()=>({}));if(r.status===401&&!u.startsWith('/auth'))logout();if(!r.ok)throw new Error(d.error||'Request failed');return d}
const fid=id=>'FT'+String(id).padStart(3,'0');
const av=(f,l)=>`<span class="av">${((f||'?')[0]+((l||'')[0]||'')).toUpperCase()}</span>`;
const fd=d=>d?new Date(d.slice(0,10)+'T00:00').toLocaleDateString('en-PH',{day:'2-digit',month:'short',year:'numeric'}):'—';
const fdt=d=>d?new Date(d.replace(' ','T')).toLocaleString('en-PH',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—';
const peso=n=>'₱'+Number(n).toLocaleString('en-PH',{minimumFractionDigits:2});
const planCls={Basic:'b-blue',Standard:'b-red',Premium:'b-amber',Annual:'b-green'};
const badge=(t,c)=>`<span class="pill ${c}">${t}</span>`;
const today=()=>new Date().toLocaleDateString('en-PH',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+' — Welcome back, '+(U?U.name.split(' ')[0]:'')+'!';
function toast(m,ok=true){const d=document.createElement('div');d.className='ft-toast '+(ok?'ok':'bad');d.textContent=m;document.body.appendChild(d);setTimeout(()=>d.remove(),3000)}
window.addEventListener('unhandledrejection',e=>toast(e.reason&&e.reason.message||'Error',false));
function modal(html,size=''){const e=document.createElement('div');e.className='modal fade';e.innerHTML=`<div class="modal-dialog modal-dialog-centered ${size}"><div class="modal-content">${html}</div></div>`;document.body.appendChild(e);const m=new bootstrap.Modal(e);e.addEventListener('hidden.bs.modal',()=>e.remove());m.show();e.hide=()=>m.hide();return e}
function confirmBox({title,text,icon,onYes,logoutStyle}){
  const btns=logoutStyle?`<button class="btn btn-outline-light flex-fill" data-bs-dismiss="modal">Cancel</button><button class="btn btn-red flex-fill" id="y">Logout</button>`:`<button class="btn btn-outline-light flex-fill" id="y">Yes</button><button class="btn btn-red flex-fill" data-bs-dismiss="modal">Cancel</button>`;
  const e=modal(`<div class="p-4 text-center"><h5>${title}</h5><i class="bi ${icon} big"></i><p class="mt-3 mb-4">${text}</p><div class="d-flex gap-2">${btns}</div></div>`);
  $('#y',e).onclick=async()=>{e.hide();try{await onYes()}catch(x){toast(x.message,false)}}}
const delBox=(what,onYes)=>confirmBox({title:'Delete confirmation',text:`Are you sure you want to delete this ${what}?`,icon:'bi-exclamation-triangle',onYes});
function pager(el,page,pages,go){
  let h=`<li class="page-item ${page==1?'disabled':''}"><a class="page-link" data-p="1">First</a></li>`;
  for(let i=Math.max(1,page-1);i<=Math.min(pages,page+2);i++)h+=`<li class="page-item ${i==page?'active':''}"><a class="page-link" data-p="${i}">${i}</a></li>`;
  if(page+2<pages)h+='<li class="page-item disabled"><a class="page-link">…</a></li>';
  h+=`<li class="page-item ${page==pages?'disabled':''}"><a class="page-link" data-p="${pages}">Last</a></li>`;
  el.innerHTML=h;el.onclick=e=>{const p=e.target.dataset.p;if(p)go(+p)}}
function shell(title,sub,active,right=''){
  if(!T||!U){location.href='login.html';return false}
  const nav=[['dashboard','Dashboard','bi-grid'],['members','Members','bi-people'],['attendance','Attendance','bi-calendar-check'],['payments','Payments','bi-currency-dollar']];
  const[fn,ln]=U.name.split(' ');
  $('#root').innerHTML=`<div class="layout"><aside class="sidebar"><div class="brand">FITTRACK<small>FITNESS CENTER</small></div>
  <div class="profile">${av(fn,ln)}<div><b>${U.name}</b><div class="role ${U.role}">${U.role==='admin'?'Admin':'Staff'}</div></div></div>
  <nav>${nav.map(n=>`<a href="${n[0]}.html" class="${active===n[0]?'active':''}"><i class="bi ${n[2]}"></i><span>${n[1]}</span></a>`).join('')}</nav>
  <div>${U.role==='admin'?`<a href="accounts.html" class="${active==='accounts'?'active':''}"><i class="bi bi-person-gear"></i><span>Accounts</span></a>`:''}<a href="#" class="text-red" id="lo"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a></div></aside>
  <div class="main"><header><div><h4>${title}</h4><small>${sub}</small></div><div class="hdr-right">${right}</div></header><div class="content" id="app"></div></div></div>`;
  $('#lo').onclick=e=>{e.preventDefault();confirmBox({title:'Logout Confirmation',text:'Are you sure you want to Logout of the FITTRACK System?',icon:'bi-power',logoutStyle:true,onYes:logout})};
  return true}
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const normPhone=v=>{const c=String(v||'').replace(/[\s\-()]/g,'');return/^(?:\+?63|0)9\d{9}$/.test(c)?'0'+c.slice(-10):null};
const phoneOk=v=>!!normPhone(v);
const addrOk=a=>{const p=String(a||'').split(',').map(x=>x.trim());return p.length>=3&&p.every(Boolean)};
const PH_MSG='Enter a valid Philippine mobile number (e.g. 0917 123 4567 or +63 917 123 4567).';
const AD_MSG='Please include barangay, city/municipality, and province, separated by commas.';
const fmtPhone=v=>String(v||'').replace(/^(\d{4})(\d{3})(\d{4})$/,'$1 $2 $3');
const expBadge=m=>m.status==='Active'&&m.days_left!=null&&m.days_left>=0&&m.days_left<=7?`<span class="pill b-amber ms-1" title="${m.days_left} day${m.days_left==1?'':'s'} left">Expiring soon</span>`:'';
const searchBox=(id,ph)=>`<div class="sbox"><i class="bi bi-search" aria-hidden="true"></i><input id="${id}" type="text" class="form-control" placeholder="${ph}" aria-label="${ph}" autocomplete="off"><button type="button" class="sclear d-none" aria-label="Clear search"><i class="bi bi-x-lg"></i></button></div>`;
function bindSearch(id,cb,ms=300){const i=$('#'+id),c=i.nextElementSibling;let t;i.addEventListener('input',()=>{c.classList.toggle('d-none',!i.value);clearTimeout(t);t=setTimeout(()=>cb(i.value.trim()),ms)});c.onclick=()=>{i.value='';c.classList.add('d-none');cb('');i.focus()}}
const sortSel=(id,opts)=>`<div class="d-flex align-items-center gap-2"><label for="${id}" class="m-0 small text-muted text-nowrap">Sort by</label><select id="${id}" class="form-select form-select-sm sortsel">${opts.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join('')}</select></div>`;
const memberLink=r=>`<a href="#" class="plink" data-mid="${r.member_id}">${av(r.first_name,r.last_name)}${esc(r.first_name)} ${esc(r.last_name)}</a>`;
function onPlink(el,cb){el.addEventListener('click',e=>{const a=e.target.closest('.plink');if(a){e.preventDefault();profileModal(a.dataset.mid,cb)}})}
const archBox=(what,restore,onYes)=>confirmBox({title:restore?'Restore confirmation':'Archive confirmation',text:restore?`Restore this ${what}?`:`Are you sure you want to archive this ${what}?${what==='member'?' You can restore them later.':' You can restore it later.'}`,icon:restore?'bi-arrow-counterclockwise':'bi-archive',onYes});
const PAY_METHODS=['Cash','GCash','Bank Transfer','Card'];
const cancelBox=(id,onDone)=>confirmBox({title:'Cancellation confirmation',text:'Are you sure you want to cancel this membership?',icon:'bi-exclamation-triangle',onYes:async()=>{const r=await api(`/members/${id}/cancel`,{method:'POST'});toast('Membership canceled');await onDone(r)}});
// date helpers for the Edit Membership modal. addMonths matches MySQL DATE_ADD(.., INTERVAL n MONTH): Jan 31 + 1 month = Feb 28/29
const todayISO=()=>new Date().toLocaleDateString('en-CA');
function addMonths(iso,n){const[y,mo,d]=iso.split('-').map(Number),t=new Date(Date.UTC(y,mo-1+n,1)),last=new Date(Date.UTC(t.getUTCFullYear(),t.getUTCMonth()+1,0)).getUTCDate();t.setUTCDate(Math.min(d,last));return t.toISOString().slice(0,10)}
// m = a row from /members or /members/:id (needs member_id, names, plan_name, plan_price, duration_months)
function renewBox(m,onDone){
  const plan=m.plan_name?`${esc(m.plan_name)} — ${peso(m.plan_price)} / ${m.duration_months} mo`:'No previous plan on record';
  const e=modal(`<div class="p-4 text-center"><h5>Renewal confirmation</h5><i class="bi bi-arrow-repeat big"></i><p class="mt-3 mb-1">Renew ${esc(m.first_name)} ${esc(m.last_name)}'s membership for a new cycle starting today?</p><p class="fw-bold">${plan}</p><div class="text-start"><label for="rpm">Payment method</label><select id="rpm" class="form-select form-select-sm sortsel w-100 mb-3">${PAY_METHODS.map(x=>`<option>${x}</option>`).join('')}</select></div><div class="d-flex gap-2"><button class="btn btn-outline-light flex-fill" id="y">Renew</button><button class="btn btn-red flex-fill" data-bs-dismiss="modal">Cancel</button></div></div>`);
  $('#y',e).onclick=async()=>{const pm=$('#rpm',e).value;e.hide();try{await api(`/members/${m.member_id}/renew`,{method:'POST',body:{payment_method:pm}});toast('Membership renewed');await onDone()}catch(x){toast(x.message,false)}}}
async function profileModal(id,onChange,startEdit=false){
  let m=await api('/members/'+id),edit=startEdit&&!m.archived_at,plans=null;
  const e=modal('<div id="pf"></div>','modal-lg');
  const reload=async()=>{m=await api('/members/'+id);draw();onChange&&onChange()};
  const act=async(fn,msg)=>{try{await fn();msg&&toast(msg);await reload()}catch(x){toast(x.message,false)}};
  // membership editor: admins only, only for the member's current membership
  const canEditMs=()=>U&&U.role==='admin'&&!m.archived_at&&!!m.membership_id;
  // ---- membership box: rendered and repainted on its own, so saving never needs a page refresh ----
  const msStats=()=>{const left=m.status==='Active'?Math.max(0,m.days_left??0):0,tot=m.start_date?Math.max(1,(new Date(m.end_date)-new Date(m.start_date))/864e5):1;return{left,pct:Math.min(100,Math.max(0,100-left/tot*100))}};
  function msBox(){
    const{left,pct}=msStats();
    return `<div class="d-flex justify-content-between align-items-start"><div><small>Membership Plan</small><h3 class="fw-bold fst-italic text-danger" id="ms_name">${esc(m.plan_name||'No plan')}</h3></div><div class="text-nowrap">${expBadge(m)}${badge(m.status,m.status==='Active'?'b-green':'b-red')}${canEditMs()?'<button class="icon-btn ms-1" id="em" title="Edit membership" aria-label="Edit membership"><i class="bi bi-pencil"></i></button>':''}</div></div>
    <div class="d-flex justify-content-between"><div><small>Join Date</small><div class="fw-bold" id="ms_from">${fd(m.start_date)}</div></div><div class="text-end"><small>End Date</small><div class="fw-bold" id="ms_to">${fd(m.end_date)}</div></div></div>
    <div class="progress my-2"><div class="progress-bar" id="msbar" style="width:${pct}%"></div></div><div class="fw-bold" id="ms_left">${left} days left in your plan</div><hr><small>Membership ID</small><div class="fw-bold">${fid(m.member_id)}</div>
    <div class="mt-3 p-2 rounded d-inline-block" style="background:#475a77"><small class="text-white">Latest check-in</small><div class="fw-bold">${fdt(m.last_check_in)}</div></div>
    <div class="d-flex gap-3 mt-3">${m.archived_at?`<button class="btn btn-green flex-fill" id="rs"><i class="bi bi-arrow-counterclockwise me-1"></i>Restore</button>`:(m.status==='Active'?`<button class="btn btn-outline-danger flex-fill" id="cm">Cancel Membership</button>`:`<button class="btn btn-outline-success flex-fill" id="rn"><i class="bi bi-arrow-repeat me-1"></i>Renewal</button>`)+(m.is_checked_in?`<button class="btn btn-red flex-fill" id="ci"><i class="bi bi-box-arrow-right me-1"></i>Check-Out</button>`:`<button class="btn btn-green flex-fill" id="ci">Check-In</button>`)}</div>`}
  // DOM update: swap the membership box for the new values (plan name, badges, dates, days left, progress bar, Cancel/Renewal button) and re-attach its handlers
  function paintMs(){
    const prev=$('#msbar',e)?.style.width;
    $('#msbox',e).innerHTML=msBox();
    const bar=$('#msbar',e),{pct}=msStats();
    if(prev){bar.style.width=prev;requestAnimationFrame(()=>requestAnimationFrame(()=>{bar.style.width=pct+'%'}))} // animate old width -> new width
    bindMs();
  }
  const refreshMs=async r=>{if(r&&r.status){m={...m,status:r.status};paintMs()} m=await api('/members/'+id);paintMs();onChange&&onChange()}; // after a cancel the new status is painted immediately from the response; then re-fetch, repaint, refresh the members list behind
  function bindMs(){
    if($('#ci',e))$('#ci',e).onclick=()=>act(async()=>{const r=await api('/attendance',{method:'POST',body:{member_id:id}});toast(r.message)});
    if($('#cm',e))$('#cm',e).onclick=()=>cancelBox(id,refreshMs);
    if($('#rn',e))$('#rn',e).onclick=()=>renewBox(m,refreshMs);
    if($('#em',e))$('#em',e).onclick=openMsEditor;
    if($('#rs',e))$('#rs',e).onclick=()=>archBox('member',true,()=>act(()=>api(`/members/${id}/restore`,{method:'POST'}),'Member restored'));
  }
  // Edit Membership is its own modal on top of the profile: it closes only after the API call succeeds, and stays open (with the error shown) if it fails
  async function openMsEditor(){
    try{plans=plans||(await api('/plans')).plans}catch(x){return toast(x.message,false)}
    const o=(v,t,on)=>`<option value="${v}" ${on?'selected':''}>${t}</option>`;
    const d=modal(`<div class="p-4"><h5 class="mb-3">Edit membership</h5><div class="row g-2"><div class="col-12"><label for="ms_plan">Plan</label><select id="ms_plan" class="form-select form-select-sm sortsel w-100">${plans.map(p=>o(p.plan_id,`${esc(p.plan_name)} — ${peso(p.price)} / ${p.duration_months} mo`,p.plan_id==m.plan_id)).join('')}</select></div>
    <div class="col-6"><label for="ms_start">Start date</label><input id="ms_start" type="date" class="form-control form-control-sm" value="${esc((m.start_date||'').slice(0,10))}"></div>
    <div class="col-6"><label for="ms_end">End date</label><input id="ms_end" type="date" class="form-control form-control-sm" value="${esc((m.end_date||'').slice(0,10))}"></div>
    <div class="col-12"><label for="ms_status">Status</label><select id="ms_status" class="form-select form-select-sm sortsel w-100">${o('Active','Active',m.status==='Active')}${o('Expired','Expired',m.status==='Expired')}${o('Membership Canceled','Membership Canceled',m.status==='Membership Canceled')}</select></div></div>
    <div id="ms_hint" class="small mt-2" aria-live="polite"></div>
    <div id="mserr" class="text-warning small mt-2" role="alert"></div><small class="d-block mt-1">An Active membership needs an end date of today or later. Changes are saved to the membership log.</small>
    <div class="d-flex gap-2 mt-3"><button class="btn btn-green flex-fill" id="msv">Save</button><button class="btn btn-outline-light flex-fill" id="msc">Cancel</button></div></div>`);
    const orig={plan:m.plan_id,start:(m.start_date||'').slice(0,10),end:(m.end_date||'').slice(0,10)};
    // choosing a different plan re-computes the dates from that plan's duration (they stay editable afterwards)
    $('#ms_plan',d).onchange=()=>{
      const p=plans.find(x=>x.plan_id==$('#ms_plan',d).value);if(!p)return;
      let start,end;
      if(p.plan_id==orig.plan){start=orig.start;end=orig.end}                   // back on the member's current plan: restore its dates
      else{start=m.status==='Active'&&orig.start?orig.start:todayISO();          // running membership keeps its start date, otherwise start today
        end=addMonths(start,p.duration_months);
        if(end<todayISO()){start=todayISO();end=addMonths(start,p.duration_months)}} // never fill in a range that has already ended
      $('#ms_start',d).value=start;$('#ms_end',d).value=end;
      $('#ms_hint',d).textContent=p.plan_id==orig.plan?'Original dates restored.':`${p.plan_name} runs ${p.duration_months} month${p.duration_months==1?'':'s'}: dates set to ${fd(start)} – ${fd(end)}. You can still adjust them.`};
    $('#msc',d).onclick=()=>d.hide();
    $('#msv',d).onclick=async()=>{
      const btn=$('#msv',d),err=$('#mserr',d),b={plan_id:+$('#ms_plan',d).value,start_date:$('#ms_start',d).value,end_date:$('#ms_end',d).value,status:$('#ms_status',d).value};
      const er=!b.start_date||!b.end_date?'Start and end dates are required':b.end_date<b.start_date?'End date cannot be before the start date':b.status==='Active'&&b.end_date<new Date().toLocaleDateString('en-CA')?'An Active membership needs an end date of today or later':'';
      if(er){err.textContent=er;return}
      btn.disabled=true;err.textContent='';
      try{await api(`/members/${id}/membership`,{method:'PUT',body:b})}catch(x){err.textContent=x.message;btn.disabled=false;return}
      d.hide();toast('Membership updated');
      refreshMs().catch(x=>toast(x.message,false));
    };
  }
  function draw(){
    const inp=(k,l,t='text',c='col-6')=>`<div class="${c}"><label for="f_${k}">${l}</label><input class="form-control form-control-sm" id="f_${k}" type="${t}" value="${esc(m[k])}"></div>`;
    $('#pf',e).innerHTML=`<div class="pf-head">${av(m.first_name,m.last_name)}<div class="flex-fill">${edit?`<div class="row g-1">${inp('first_name','First name')}${inp('last_name','Last name')}${inp('email','Email','email')}${inp('phone','Contact number')}${inp('emergency_contact_name','Emergency contact name')}${inp('emergency_contact','Emergency contact number')}${inp('date_of_birth','Birthday','date')}${inp('address','Address','text','col-12')}</div><div id="ferr" class="text-warning small mt-1"></div><div class="mt-2"><button class="btn btn-sm btn-green" id="sv">Save</button> <button class="btn btn-sm btn-outline-light" id="cn">Cancel</button></div>`:
    `<h4 class="mb-1">${esc(m.first_name)} ${esc(m.last_name)} ${m.archived_at?badge('Archived','b-amber'):''}</h4><div>${esc(m.email)}</div><div>${esc(fmtPhone(m.phone))}</div><div>Emergency contact: ${esc(m.emergency_contact_name||'—')} — ${esc(fmtPhone(m.emergency_contact))}</div><div>Birthday: ${fd(m.date_of_birth)}</div><div>${esc(m.address)}</div><b>ID: ${fid(m.member_id)}</b>`}</div>${edit||m.archived_at?'':'<button class="btn text-white fs-5" id="ed" aria-label="Edit profile"><i class="bi bi-pencil-square"></i></button>'}</div>
    <div class="pf-box" id="msbox"></div>`;
    if(edit){$('#cn',e).onclick=()=>{edit=false;draw()};
      $('#sv',e).onclick=()=>{const b={};['first_name','last_name','email','phone','emergency_contact_name','emergency_contact','date_of_birth','address'].forEach(k=>b[k]=$('#f_'+k,e).value.trim());
        const er=!phoneOk(b.phone)?'Phone: '+PH_MSG:!phoneOk(b.emergency_contact)?'Emergency contact: '+PH_MSG:!addrOk(b.address)?AD_MSG:!b.emergency_contact_name?'Emergency contact name is required':'';
        if(er){$('#ferr',e).textContent=er;return}b.phone=normPhone(b.phone);b.emergency_contact=normPhone(b.emergency_contact);
        act(async()=>{await api('/members/'+id,{method:'PUT',body:b});edit=false},'Profile updated')}}
    else if($('#ed',e))$('#ed',e).onclick=()=>{edit=true;draw()};
    paintMs();
  }
  draw()}
