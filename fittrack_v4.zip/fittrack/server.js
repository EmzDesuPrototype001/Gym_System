require('dotenv').config();
const express=require('express'),mysql=require('mysql2/promise'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),path=require('path');
const app=express();app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
app.get('/',(q,s)=>s.redirect('/login.html'));
const db=mysql.createPool({host:process.env.DB_HOST||'localhost',user:process.env.DB_USER||'root',password:process.env.DB_PASS||'',database:'gym_system',dateStrings:true});
const SECRET=process.env.JWT_SECRET||'change-me',PER=10;
const h=f=>(q,s,n)=>f(q,s,n).catch(e=>{console.error(e);const d=e.code==='ER_DUP_ENTRY',ck=e.code==='ER_CHECK_CONSTRAINT_VIOLATED'||e.errno===3819||e.errno===4025;s.status(e.status||(d?409:500)).json({error:e.status?e.message:d?'Email already exists':ck?(/tbl_attendance/.test(e.sqlMessage||'')?'Check-out time cannot be earlier than the check-in time.':'The database status rule is out of date. Run db/migration_v5.sql, then try again.'):(e.sqlMessage||e.message)})});
const bad=m=>{const e=new Error(m);e.status=400;throw e};
const PAY=['Cash','GCash','Bank Transfer','Card'];
const CANCELED='Membership Canceled'; // exact status string stored when a membership is cancelled
// effective status of a membership row `ms`: Active until its end date passes; a cancelled one stays cancelled; anything else is Expired
const EFF=`IF(ms.status='Active' AND ms.end_date>=CURDATE(),'Active',IF(ms.status='${CANCELED}','${CANCELED}','Expired'))`;
// calendar-month window, evaluated by MySQL on every query: revenue "resets" itself on the 1st with no cron job
const MONTH_START='DATE_SUB(CURDATE(),INTERVAL DAYOFMONTH(CURDATE())-1 DAY)',MONTH_END=`DATE_ADD(${MONTH_START},INTERVAL 1 MONTH)`;
const money=n=>'₱'+Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
// the one place the earnings text is built: "September 2026: ₱100,000.00" (English month name regardless of the MySQL server's locale)
const earnings=(y,m,total)=>`${new Date(Date.UTC(y,m-1,1)).toLocaleString('en-US',{month:'long',year:'numeric',timeZone:'UTC'})}: ${money(total)}`;
const tx=async f=>{const c=await db.getConnection();try{await c.beginTransaction();const r=await f(c);await c.commit();return r}catch(e){await c.rollback();throw e}finally{c.release()}};
// row lock on the member: concurrent renew/cancel/edit requests for one member are serialised
const lockMember=async(c,id)=>{const[[m]]=await c.query('SELECT member_id,archived_at FROM tbl_members WHERE member_id=? FOR UPDATE',[id]);if(!m){const e=new Error('Member not found');e.status=404;throw e}return m};
// the member's current (latest) membership; status = effective status (an Active row past its end date counts as Expired)
const latestMs=async(c,id)=>(await c.query("SELECT ms.membership_id,ms.plan_id,p.plan_name,p.price,p.duration_months,ms.start_date,ms.end_date,ms.status AS stored_status,"+EFF+" AS status FROM tbl_memberships ms JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id WHERE ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=?)",[id]))[0][0];
// audit trail of membership changes (performed_by is NULL for system actions)
const logMs=(c,memberId,membershipId,action,details,user)=>c.query('INSERT INTO tbl_membership_log(member_id,membership_id,action,details,performed_by) VALUES(?,?,?,?,?)',[memberId,membershipId,action,String(details).slice(0,500),user?user.id:null]);
// membership audit table. Created here if absent, so renew / cancel / edit can never fail with "Table 'gym_system.tbl_membership_log' doesn't exist"
// (same DDL as db/migration_v4.sql; it needs tbl_members, tbl_memberships and tbl_users, which every install has)
const ensureSchema=()=>db.query(`CREATE TABLE IF NOT EXISTS tbl_membership_log (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  member_id INT NOT NULL,
  membership_id INT NULL,
  action VARCHAR(30) NOT NULL,
  details VARCHAR(500) NOT NULL DEFAULT '',
  performed_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (action IN ('Renewed','Cancelled','Edited','Auto-expired')),
  FOREIGN KEY (member_id) REFERENCES tbl_members(member_id),
  FOREIGN KEY (membership_id) REFERENCES tbl_memberships(membership_id),
  FOREIGN KEY (performed_by) REFERENCES tbl_users(user_id) ON DELETE SET NULL,
  INDEX idx_membership_log_member (member_id, created_at)
)`);
// persists "Expired" once an end date has passed (and logs it). Reads below also derive status from end_date, so they are correct between syncs.
const syncStatuses=async()=>{
  await db.query("INSERT INTO tbl_membership_log(member_id,membership_id,action,details) SELECT member_id,membership_id,'Auto-expired',CONCAT('End date ',end_date,' passed') FROM tbl_memberships WHERE status='Active' AND end_date<CURDATE()");
  await db.query("UPDATE tbl_memberships SET status='Expired' WHERE status='Active' AND end_date<CURDATE()");
  await db.query(`UPDATE tbl_members m LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(x.membership_id) FROM tbl_memberships x WHERE x.member_id=m.member_id) SET m.status=${EFF}`);
};
// auth re-checks the DB so deactivating/archiving a user ends their session immediately
const auth=async(q,s,n)=>{try{const u=jwt.verify((q.headers.authorization||'').slice(7),SECRET);
  const[[r]]=await db.query('SELECT role,status,archived_at FROM tbl_users WHERE user_id=?',[u.id]);
  if(!r||r.status!=='Active'||r.archived_at)return s.status(401).json({error:'Session ended'});q.user={...u,role:r.role};}catch{return s.status(401).json({error:'Unauthorized'})}n()};
const admin=(q,s,n)=>q.user.role==='admin'?n():s.status(403).json({error:'Admin only'});
const MEM=`SELECT m.member_id,m.first_name,m.last_name,m.email,m.phone,m.emergency_contact,m.emergency_contact_name,m.date_of_birth,m.address,m.archived_at,ms.membership_id,ms.plan_id,p.plan_name,p.price AS plan_price,p.duration_months,ms.start_date,ms.end_date,DATEDIFF(ms.end_date,CURDATE()) AS days_left,EXISTS(SELECT 1 FROM tbl_attendance WHERE member_id=m.member_id AND check_out IS NULL) AS is_checked_in,${EFF} AS status FROM tbl_members m LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=m.member_id) LEFT JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id`;
const page=async(s,q,cnt,sql,a=[],extra={},map=null)=>{const pg=Math.max(1,+q.query.page||1);const[[{n}]]=await db.query(cnt,a);const[rows]=await db.query(sql+' LIMIT ? OFFSET ?',[...a,PER,(pg-1)*PER]);s.json({rows:map?rows.map(map):rows,total:n,pages:Math.ceil(n/PER)||1,...extra})};
const num=v=>String(v||'').replace(/\D/g,'');
// sort keys are whitelisted; first key is the default; id tiebreaker always appended
const ord=(map,k,idc)=>' ORDER BY '+(Object.prototype.hasOwnProperty.call(map,k)?map[k]:Object.values(map)[0])+','+idc;
const SM={id_asc:'m.member_id',id_desc:'m.member_id DESC',name_asc:'m.last_name,m.first_name',name_desc:'m.last_name DESC,m.first_name DESC',plan:'p.plan_name IS NULL,p.plan_name',end_asc:'ms.end_date IS NULL,ms.end_date',end_desc:'ms.end_date IS NULL,ms.end_date DESC',status:"(ms.status='Active' AND ms.end_date>=CURDATE()) DESC"};
const SA={newest:'a.check_in DESC',oldest:'a.check_in',name_asc:'m.last_name,m.first_name',name_desc:'m.last_name DESC,m.first_name DESC',inside:'(a.check_out IS NULL) DESC,a.check_in DESC'};
const SP={newest:'pay.payment_date DESC',oldest:'pay.payment_date',amount_desc:'pay.amount DESC',amount_asc:'pay.amount',name_asc:'m.last_name,m.first_name',method:'pay.payment_method'};
const SU={name_asc:'first_name,last_name',name_desc:'first_name DESC,last_name DESC',status:'status',newest:'user_id DESC',oldest:'user_id'};
const normPhone=v=>{const c=String(v||'').replace(/[\s\-()]/g,'');return/^(?:\+?63|0)9\d{9}$/.test(c)?'0'+c.slice(-10):null};
const addrOk=a=>{const p=String(a||'').split(',').map(x=>x.trim());return p.length>=3&&p.every(Boolean)};
function vm(b){for(const k of['first_name','last_name','email','emergency_contact_name','address'])b[k]=String(b[k]||'').trim();
  if(!b.first_name||!b.last_name||!b.email||!b.emergency_contact_name||!b.date_of_birth)bad('Please fill in all required fields');
  const p=normPhone(b.phone),e=normPhone(b.emergency_contact);
  if(!p)bad('Enter a valid Philippine mobile number for Phone Number');
  if(!e)bad('Enter a valid Philippine mobile number for Emergency Contact Number');
  if(!addrOk(b.address))bad('Please include barangay, city/municipality, and province, separated by commas.');
  b.phone=p;b.emergency_contact=e}

app.post('/api/auth/login',h(async(q,s)=>{
  const[[u]]=await db.query('SELECT * FROM tbl_users WHERE email=? AND status="Active" AND archived_at IS NULL',[q.body.email||'']);
  if(!u||!await bcrypt.compare(q.body.password||'',u.password_hash))return s.status(401).json({error:'Invalid email or password'});
  const user={id:u.user_id,name:u.first_name+' '+u.last_name,email:u.email,role:u.role};
  s.json({token:jwt.sign(user,SECRET,{expiresIn:'8h'}),user});
}));
app.use('/api',auth);

app.get('/api/dashboard',h(async(q,s)=>{
  const[[{total}]]=await db.query('SELECT COUNT(*) total FROM tbl_members WHERE archived_at IS NULL');
  const[[{today}]]=await db.query('SELECT COUNT(DISTINCT a.member_id) today FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id WHERE DATE(a.check_in)=CURDATE() AND m.archived_at IS NULL');
  const[expiring]=await db.query(`SELECT m.member_id,m.first_name,m.last_name,DATEDIFF(ms.end_date,CURDATE()) days_left FROM tbl_memberships ms JOIN tbl_members m ON m.member_id=ms.member_id WHERE m.archived_at IS NULL AND ms.status='Active' AND ms.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY) ORDER BY ms.end_date,m.member_id`);
  const[recent]=await db.query('SELECT a.member_id,m.first_name,m.last_name,a.check_in,a.check_out FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id ORDER BY a.check_in DESC,a.attendance_id DESC LIMIT 5');
  s.json({total,today,expiring,recent});
}));

app.get('/api/plans',h(async(q,s)=>{
  const[plans]=await db.query('SELECT * FROM tbl_membership_plans ORDER BY plan_id');
  const[ps]=await db.query('SELECT plan_id,service_id FROM tbl_plan_services');
  const[services]=await db.query('SELECT * FROM tbl_services ORDER BY service_id');
  plans.forEach(p=>p.included=ps.filter(x=>x.plan_id===p.plan_id).map(x=>x.service_id));
  s.json({plans,services});
}));

app.get('/api/members',h(async(q,s)=>{
  const t=`%${q.query.search||''}%`,a=[t,t,t,t,+q.query.search||0];
  const w=` WHERE m.archived_at IS ${q.query.archived==='1'?'NOT NULL':'NULL'} AND (CONCAT(m.first_name," ",m.last_name) LIKE ? OR m.email LIKE ? OR m.phone LIKE ? OR CONCAT("FT",LPAD(m.member_id,3,"0")) LIKE ? OR m.member_id=?)`;
  await page(s,q,'SELECT COUNT(*) n FROM tbl_members m'+w,MEM+w+ord(SM,q.query.sort,'m.member_id'),a);
}));
app.get('/api/members/:id',h(async(q,s)=>{
  const id=num(q.params.id);const[[m]]=await db.query(MEM+' WHERE m.member_id=?',[id]);
  if(!m)return s.status(404).json({error:'Member not found'});
  const[[a]]=await db.query('SELECT MAX(check_in) last_check_in FROM tbl_attendance WHERE member_id=?',[id]);
  s.json({...m,...a,is_checked_in:!!m.is_checked_in});
}));
app.post('/api/members',h(async(q,s)=>{
  const b=q.body;vm(b);const c=await db.getConnection();
  try{await c.beginTransaction();
    const[[p]]=await c.query('SELECT * FROM tbl_membership_plans WHERE plan_id=?',[b.plan_id]);if(!p)bad('Select a membership plan');
    if(!PAY.includes(b.payment_method))bad('Select a payment method');
    const[inc]=await c.query('SELECT service_id FROM tbl_plan_services WHERE plan_id=?',[p.plan_id]);const incl=inc.map(x=>x.service_id);
    let total=+p.price;
    for(const sid of b.addons||[]){if(incl.includes(+sid))continue;const[[sv]]=await c.query('SELECT price FROM tbl_services WHERE service_id=?',[sid]);if(sv)total+=+sv.price}
    const[r]=await c.query('INSERT INTO tbl_members(first_name,last_name,email,phone,emergency_contact_name,emergency_contact,date_of_birth,address,registration_date) VALUES(?,?,?,?,?,?,?,?,CURDATE())',[b.first_name,b.last_name,b.email,b.phone,b.emergency_contact_name,b.emergency_contact,b.date_of_birth,b.address]);
    const[ms]=await c.query('INSERT INTO tbl_memberships(member_id,plan_id,start_date,end_date,status) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL ? MONTH),"Active")',[r.insertId,p.plan_id,p.duration_months]);
    await c.query('INSERT INTO tbl_payments(membership_id,amount,payment_method) VALUES(?,?,?)',[ms.insertId,total,b.payment_method]);
    await c.commit();s.json({member_id:r.insertId,total});
  }catch(e){await c.rollback();throw e}finally{c.release()}
}));
app.put('/api/members/:id',h(async(q,s)=>{
  const b=q.body;vm(b);
  await db.query('UPDATE tbl_members SET first_name=?,last_name=?,email=?,phone=?,emergency_contact_name=?,emergency_contact=?,date_of_birth=?,address=? WHERE member_id=?',[b.first_name,b.last_name,b.email,b.phone,b.emergency_contact_name,b.emergency_contact,b.date_of_birth,b.address,num(q.params.id)]);s.json({ok:true});
}));
// no hard delete: members are archived; payments and attendance are never removed
app.post('/api/members/:id/archive',h(async(q,s)=>{
  const id=num(q.params.id);await db.query('UPDATE tbl_attendance SET check_out=NOW() WHERE member_id=? AND check_out IS NULL',[id]);
  await db.query('UPDATE tbl_members SET archived_at=NOW() WHERE member_id=?',[id]);s.json({ok:true});
}));
app.post('/api/members/:id/restore',h(async(q,s)=>{await db.query('UPDATE tbl_members SET archived_at=NULL WHERE member_id=?',[num(q.params.id)]);s.json({ok:true})}));
app.post('/api/members/:id/cancel',h(async(q,s)=>{
  const id=num(q.params.id);
  s.json(await tx(async c=>{
    const m=await lockMember(c,id);
    if(m.archived_at)bad('Archived members cannot be modified');
    const cur=await latestMs(c,id);
    if(!cur)bad('This member has no membership to cancel');
    if(cur.status!=='Active')bad(cur.status===CANCELED?'Membership is already canceled':'Membership is already expired');
    await c.query('UPDATE tbl_memberships SET status=? WHERE membership_id=?',[CANCELED,cur.membership_id]);
    await c.query('UPDATE tbl_members SET status=? WHERE member_id=?',[CANCELED,id]);
    await logMs(c,id,cur.membership_id,'Cancelled',`${cur.plan_name} (${cur.start_date} to ${cur.end_date}) canceled`,q.user);
    return{ok:true,status:CANCELED};
  }));
}));
// renewal: a NEW membership row (cycle history is kept) on the member's last plan, plus the payment for it so revenue stays correct
app.post('/api/members/:id/renew',h(async(q,s)=>{
  const id=num(q.params.id),pm=q.body.payment_method;
  if(!PAY.includes(pm))bad('Select a payment method');
  s.json(await tx(async c=>{
    const m=await lockMember(c,id);
    if(m.archived_at)bad('Archived members cannot be renewed');
    const cur=await latestMs(c,id);
    if(!cur)bad('No previous membership plan to renew');
    if(cur.status==='Active')bad('Membership is still active');
    const[[d]]=await c.query('SELECT CURDATE() s,DATE_ADD(CURDATE(),INTERVAL ? MONTH) e',[cur.duration_months]);
    const[ms]=await c.query("INSERT INTO tbl_memberships(member_id,plan_id,start_date,end_date,status) VALUES(?,?,?,?,'Active')",[id,cur.plan_id,d.s,d.e]);
    await c.query('INSERT INTO tbl_payments(membership_id,amount,payment_method) VALUES(?,?,?)',[ms.insertId,cur.price,pm]);
    await c.query("UPDATE tbl_members SET status='Active' WHERE member_id=?",[id]);
    await logMs(c,id,ms.insertId,'Renewed',`${cur.plan_name}: ${d.s} to ${d.e}; ${money(cur.price)} via ${pm}`,q.user);
    return{ok:true,membership_id:ms.insertId,amount:+cur.price};
  }));
}));
// admin-only: edit the member's current membership (plan, dates, status) from the profile pop-up
app.put('/api/members/:id/membership',admin,h(async(q,s)=>{
  const id=num(q.params.id),b=q.body,dOk=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'')&&!isNaN(new Date(v));
  if(!['Active','Expired',CANCELED].includes(b.status))bad('Invalid status');
  if(!dOk(b.start_date)||!dOk(b.end_date))bad('Valid start and end dates are required');
  if(b.end_date<b.start_date)bad('End date cannot be before the start date');
  s.json(await tx(async c=>{
    const m=await lockMember(c,id);
    if(m.archived_at)bad('Archived members cannot be edited');
    const[[plan]]=await c.query('SELECT plan_id,plan_name FROM tbl_membership_plans WHERE plan_id=?',[b.plan_id]);
    if(!plan)bad('Select a membership plan');
    const cur=await latestMs(c,id);
    if(!cur)bad('This member has no membership to edit');
    const[[{past}]]=await c.query('SELECT DATE(?)<CURDATE() AS past',[b.end_date]);
    if(b.status==='Active'&&past)bad("An Active membership can't have an end date in the past. Set the status to Expired or choose a later end date.");
    const ch=[];
    if(cur.plan_id!==plan.plan_id)ch.push(`Plan: ${cur.plan_name} -> ${plan.plan_name}`);
    if(cur.start_date!==b.start_date)ch.push(`Start: ${cur.start_date} -> ${b.start_date}`);
    if(cur.end_date!==b.end_date)ch.push(`End: ${cur.end_date} -> ${b.end_date}`);
    if(cur.stored_status!==b.status)ch.push(`Status: ${cur.stored_status} -> ${b.status}`);
    if(!ch.length)return{ok:true,changed:false};
    await c.query('UPDATE tbl_memberships SET plan_id=?,start_date=?,end_date=?,status=? WHERE membership_id=?',[plan.plan_id,b.start_date,b.end_date,b.status,cur.membership_id]);
    await c.query('UPDATE tbl_members SET status=? WHERE member_id=?',[b.status,id]);
    await logMs(c,id,cur.membership_id,'Edited',ch.join('; '),q.user);
    return{ok:true,changed:true};
  }));
}));

app.post('/api/attendance',h(async(q,s)=>{
  const id=num(q.body.member_id);const[[m]]=await db.query(MEM+' WHERE m.member_id=?',[id]);
  if(!m)return s.status(404).json({error:'Member not found'});
  const[[open]]=await db.query('SELECT attendance_id FROM tbl_attendance WHERE member_id=? AND check_out IS NULL ORDER BY check_in DESC LIMIT 1',[id]);
  if(open){await db.query('UPDATE tbl_attendance SET check_out=NOW() WHERE attendance_id=?',[open.attendance_id]);return s.json({action:'out',message:m.first_name+' checked out'})}
  if(m.archived_at)return s.status(400).json({error:'Archived members cannot check in'});
  if(m.status!=='Active')return s.status(400).json({error:m.status===CANCELED?'Membership is canceled. Please renew it first.':'Membership has expired. Please renew it first.'});
  await db.query('INSERT INTO tbl_attendance(member_id) VALUES(?)',[id]);s.json({action:'in',message:m.first_name+' checked in'});
}));
app.get('/api/attendance',h(async(q,s)=>{
  const t=`%${q.query.search||''}%`,w=' WHERE CONCAT(m.first_name," ",m.last_name) LIKE ? OR CONCAT("FT",LPAD(m.member_id,3,"0")) LIKE ?';
  const j=' FROM tbl_attendance a JOIN tbl_members m ON m.member_id=a.member_id LEFT JOIN tbl_memberships ms ON ms.membership_id=(SELECT MAX(membership_id) FROM tbl_memberships WHERE member_id=m.member_id) LEFT JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id'+w;
  await page(s,q,'SELECT COUNT(*) n'+j,'SELECT a.attendance_id,m.member_id,m.first_name,m.last_name,p.plan_name,a.check_in,a.check_out'+j+ord(SA,q.query.sort,'a.attendance_id'),[t,t]);
}));
// headline revenue is ALWAYS the current calendar month, formatted "Month Year: ₱0.00"
const curRev=async()=>{const[[{total,y,m}]]=await db.query(`SELECT COALESCE(SUM(amount),0) total,YEAR(CURDATE()) y,MONTH(CURDATE()) m FROM tbl_payments WHERE payment_date>=${MONTH_START} AND payment_date<${MONTH_END}`);return{revenue:total,display:earnings(y,m,total)}};
app.get('/api/payments',h(async(q,s)=>{
  const w=` WHERE pay.payment_date>=${MONTH_START} AND pay.payment_date<${MONTH_END}`; // transactions for the current month; earlier months live in Monthly Records
  const j=' FROM tbl_payments pay JOIN tbl_memberships ms ON ms.membership_id=pay.membership_id JOIN tbl_members m ON m.member_id=ms.member_id JOIN tbl_membership_plans p ON p.plan_id=ms.plan_id'+w;
  await page(s,q,'SELECT COUNT(*) n'+j,'SELECT pay.payment_id,pay.amount,pay.payment_date,pay.payment_method,m.member_id,m.first_name,m.last_name,p.plan_name'+j+ord(SP,q.query.sort,'pay.payment_id'),[],await curRev());
}));
// one row per calendar month that has payments; each row's `display` is exactly "September 2026: ₱100,000.00"
const SMO={newest:'yr DESC,mo DESC',oldest:'yr,mo',amount_desc:'total DESC',amount_asc:'total'};
app.get('/api/payments/monthly',h(async(q,s)=>{
  const g=' FROM tbl_payments GROUP BY YEAR(payment_date),MONTH(payment_date)';
  await page(s,q,'SELECT COUNT(*) n FROM (SELECT 1'+g+') t',"SELECT YEAR(payment_date) yr,MONTH(payment_date) mo,SUM(amount) total"+g+ord(SMO,q.query.sort,'yr DESC,mo DESC'),[],await curRev(),r=>({yr:r.yr,mo:r.mo,total:r.total,display:earnings(r.yr,r.mo,r.total)}));
}));

app.get('/api/accounts',admin,h(async(q,s)=>{
  const[rows]=await db.query(`SELECT user_id,first_name,last_name,email,phone,status,archived_at FROM tbl_users WHERE role='staff' AND archived_at IS ${q.query.archived==='1'?'NOT NULL':'NULL'}`+ord(SU,q.query.sort,'user_id'));s.json(rows);
}));
app.post('/api/accounts',admin,h(async(q,s)=>{
  const b=q.body;if(!b.first_name||!b.last_name||!b.email||!b.phone||!b.password||b.password.length<6)bad('All fields required (password min 6 chars)');
  if(b.password!==b.confirm_password)bad('Passwords do not match');
  await db.query("INSERT INTO tbl_users(first_name,last_name,email,phone,password_hash,role) VALUES(?,?,?,?,?,'staff')",[b.first_name,b.last_name,b.email,b.phone,await bcrypt.hash(b.password,10)]);s.json({ok:true});
}));
app.patch('/api/accounts/:id/status',admin,h(async(q,s)=>{
  if(!['Active','Inactive'].includes(q.body.status))bad('Invalid status');
  await db.query("UPDATE tbl_users SET status=? WHERE user_id=? AND role='staff'",[q.body.status,q.params.id]);s.json({ok:true});
}));
app.post('/api/accounts/:id/archive',admin,h(async(q,s)=>{await db.query("UPDATE tbl_users SET archived_at=NOW() WHERE user_id=? AND role='staff'",[q.params.id]);s.json({ok:true})}));
app.post('/api/accounts/:id/restore',admin,h(async(q,s)=>{await db.query("UPDATE tbl_users SET archived_at=NULL,status='Inactive' WHERE user_id=? AND role='staff'",[q.params.id]);s.json({ok:true})}));

// Brings the status CHECK rules up to date at startup (same steps as db/migration_v5.sql), so nobody has to run SQL by hand.
// It does nothing once the rules already allow 'Membership Canceled'. Works on MySQL 8 and MariaDB (XAMPP).
const migrateStatusRules=async()=>{
  const[rows]=await db.query("SELECT tc.TABLE_NAME t,tc.CONSTRAINT_NAME n,cc.CHECK_CLAUSE c FROM information_schema.TABLE_CONSTRAINTS tc JOIN information_schema.CHECK_CONSTRAINTS cc ON cc.CONSTRAINT_SCHEMA=tc.CONSTRAINT_SCHEMA AND cc.CONSTRAINT_NAME=tc.CONSTRAINT_NAME WHERE tc.CONSTRAINT_SCHEMA=DATABASE() AND tc.TABLE_NAME IN ('tbl_members','tbl_memberships') AND tc.CONSTRAINT_TYPE='CHECK' AND cc.CHECK_CLAUSE LIKE '%status%'");
  const old=rows.filter(r=>!r.c.includes(CANCELED));
  if(!old.length)return;
  for(const r of old){const alter=w=>`ALTER TABLE \`${r.t}\` ${w} \`${r.n}\``;try{await db.query(alter('DROP CONSTRAINT'))}catch{await db.query(alter('DROP CHECK'))}}
  const tables=[...new Set(old.map(r=>r.t))],ok=`'Active','Expired','${CANCELED}'`;
  for(const t of tables)await db.query(`UPDATE ${t} SET status='Expired' WHERE status NOT IN (${ok})`); // legacy 'Inactive' -> 'Expired'
  for(const t of tables)await db.query(`ALTER TABLE ${t} ADD CONSTRAINT chk_${t.replace('tbl_','')}_status CHECK (status IN (${ok}))`);
  console.log(`Updated the status rule on ${tables.join(' and ')}: now allows ${ok}.`);
};
ensureSchema().then(()=>migrateStatusRules()).then(()=>syncStatuses()).catch(e=>console.error('Startup status migration/sync failed. Run db/migration_v5.sql manually:',e.message));
setInterval(()=>syncStatuses().catch(console.error),15*60*1000);
app.listen(process.env.PORT||3000,()=>console.log('FitTrack running on http://localhost:'+(process.env.PORT||3000)));
